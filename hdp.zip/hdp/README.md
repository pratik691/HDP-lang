# HDP — High Definition Programming

A programming language simpler than Python — that can also make 3D games,
including Minecraft-style block worlds, in Chrome or Firefox.

```
hdp.cpp            the language (C++), runs programs on your computer
web/hdp-web.html   HDP Studio — write and run HDP in the browser (3D + block worlds)
examples/          tour, guess, coins (3D game), craft (Minecraft, browser)
```

## Three ways to run HDP

**1. In the browser (easiest — nothing to install).**
Double-click `web/hdp-web.html` (Chrome or Firefox, needs internet the first
time to load the 3D engine). Pick an example, press **▶ Run** or **Ctrl+Enter**.

**2. On your computer, text programs only.**
```
g++ -std=c++17 -O2 -o hdp hdp.cpp
hdp examples/tour.hdp
```

**3. On your computer, with 3D games** (uses the free raylib library).
- Windows: download `raylib-5.5_win64_mingw-w64.zip` from
  github.com/raysan5/raylib/releases, unzip it next to `hdp.cpp` as a folder
  called `raylib`, then:
  ```
  g++ -std=c++17 -O2 -DHDP_GAMES hdp.cpp -o hdp.exe -I raylib/include -L raylib/lib -lraylib -lopengl32 -lgdi32 -lwinmm
  hdp examples/coins.hdp
  ```
- Mac: `brew install raylib`, then
  `g++ -std=c++17 -O2 -DHDP_GAMES hdp.cpp -o hdp $(pkg-config --cflags --libs raylib)`
- Linux: build raylib from source, then link with `-lraylib -lGL -lm -lpthread -ldl -lrt -lX11`.

The block-world functions (Minecraft) are in the browser version only for now.

## The language on one page

```
# comments start with #
say "Hello"                       # print
name = ask "Your name? "          # read input (typing 42 gives the number 42)
x = 10                            # variables: no types, no 'let'
x += 5                            # also -=  *=  /=

7 / 2 → 3.5     2 ^ 3 → 8     17 mod 5 → 2     "Age: " + 30 → "Age: 30"

if x > 10                         # no colons, indent however you like
    say "big"
else if x is 10                   # 'is', '=' and '==' all mean "equals" here
    say "ten"
else
    say "small"
end

repeat 3 times ... end
for i from 1 to 10 ... end        # 'step 2' optional; counts down by itself
for item in my_list ... end
while x < 100 ... end
stop / skip                       # break / continue
and  or  not  in   true  false  nothing

fruits = ["apple", "mango"]       # fruits[0] first, fruits[-1] last
function add(a, b)                # can be called before it's written
    return a + b
end
```

**Built-ins:** `size` `add` `insert` `remove` `sort` `reverse` `sum` `average`
`min` `max` · `upper` `lower` `trim` `split` `join` `replace` · `number` `text`
`type` · `round` `floor` `ceil` `abs` `sqrt` `random(6)` `random(5, 10)`
`sin` `cos` `tan` (degrees) `pi` · `distance(x1,y1,z1, x2,y2,z2)`
`touching(x1,y1,z1,size1, x2,y2,z2,size2)`

## Making a 3D game

```
window(1000, 700, "My Game")
while game_running()
    if key_down("d")
        x += 5 * delta()          # delta() = seconds since last frame
    end
    camera(0, 8, 10,  0, 0, 0)    # where the camera is, and what it looks at
    draw
        ground(30, "grass")
        cube(x, 0.5, 0, 1, "red")
        text("Score: " + score, 20, 20, 30, "gold")
    end
end
```

| Shapes (inside `draw`) | Camera & window | Input |
|---|---|---|
| `cube(x,y,z, size, color)` | `window(w, h, title)` | `key_down("w")` held |
| `box(x,y,z, w,h,d, color)` | `game_running()` | `key_pressed("space")` just pressed |
| `sphere(x,y,z, r, color)` | `background(color)` | `mouse_x()` `mouse_y()` |
| `cylinder` / `cone(x,y,z, r, h, color)` | `camera(x,y,z, lx,ly,lz)` | `mouse_down("left")` |
| `ground(size, color)` `grid()` | `first_person()` `orbit_camera()` | `mouse_clicked("right")` |
| `line3d(x1,y1,z1, x2,y2,z2, color)` | `zoom(degrees)` | `mouse_wheel()` (browser) |
| `text(msg, x, y, size, color)` `rect(x, y, w, h, color)` | `delta()` `seconds()` `fps()` | `beep(440)` (browser) `play_sound("a.wav")` (desktop) |

Colors: `"red"`, `"dark green"`, `"gold"`, `"sky"`, `"sand"`… or `[255, 128, 0]`.
Desktop only: `load_model("car.glb")`, `model(id, x, y, z, scale)`, `screenshot("shot.png")`.

## Minecraft-style worlds (browser)

```
place_block(x, y, z, "stone")         remove_block(x, y, z)
block_at(x, y, z)  → "stone" or nothing
fill_blocks(x1,y1,z1, x2,y2,z2, "dirt")   # "air" clears
noise(x, z)  → smooth hills 0..1      seed(7)
top_block(x, z)  → height of the column
player(x, y, z)                       # walk: WASD, Space jump, mouse look
player_x()  player_y()  player_z()  on_ground()  walk_speed(5)  fly(true)
target_block() → [x, y, z] you look at      target_side() → where a new block goes
hotbar(["grass", "stone"], chosen)
```

Blocks: grass, dirt, stone, cobblestone, sand, wood, planks, leaves, glass,
brick, water, snow, bedrock, coal, gold, diamond, tnt, gravel, ice, wool.

See `examples/craft.hdp` for a complete Minecraft in about 80 lines.
